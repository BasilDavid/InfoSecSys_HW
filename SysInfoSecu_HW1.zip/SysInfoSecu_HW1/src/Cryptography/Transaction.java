/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cryptography;

import java.io.Serializable;

/**
 *
 * @author BaSiL DaViD
 */
public class Transaction implements Serializable{

    private float value;
    private String sender;
    private String receiver;
    private String signature;

    public Transaction(float value, String sender, String receiver, String signature) {
        this.value = value;
        this.sender = sender;
        this.receiver = receiver;
        this.signature = signature;
    }

    public Transaction() {
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

}
