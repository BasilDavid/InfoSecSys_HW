/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerClient;

import Cryptography.AES;
import Cryptography.RSA;
import Cryptography.SHA512;
import Cryptography.Transaction;
import Cryptography.Transactions;
import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import tools.SerializationTool;

/**
 *
 * @author Mohammad ALow
 */
public class Client {

    public static void main(String[] args) {
        Transactions transactions = new Transactions();
        RSA rsa = new RSA(1024);
        Socket socket = null;
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;

        Socket secSocket = null;
        ObjectInputStream secOis = null;
        ObjectOutputStream secOos = null;

        String key = "iXHD8THFk5rUOGKV8QBp";
        System.out.println("Please Enter Your Port");
        int port = new Scanner(System.in).nextInt();
        try {
            socket = new Socket("localhost", port);
            secSocket = new Socket("localhost", port + 1000);
            System.out.println("Client Started on port : " + port);
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            secOis = new ObjectInputStream(secSocket.getInputStream());
            secOos = new ObjectOutputStream(secSocket.getOutputStream());

            Scanner scan = new Scanner(System.in);
            int state = 0;
            while (true) {

                AES aes = new AES();
                aes.setKey(key);
                String message = (String) ois.readObject();
                message = aes.decrypt(message);
                System.out.println(message);
                aes = null;

                aes = new AES();
                aes.setKey(key);
                state = scan.nextInt();
                message = aes.encrypt(String.valueOf(state));
                oos.writeObject(message + "\n");
                aes = null;

                switch (state) {
                    case 1: {
                        aes = new AES();
                        aes.setKey(key);
                        message = (String) ois.readObject();
                        message = aes.decrypt(message);
                        System.out.println("Your Balance is : " + message);
                        aes = null;

                        break;
                    }
                    case 2: {
                        aes = new AES();
                        aes.setKey(key);
                        message = (String) ois.readObject();
                        message = aes.decrypt(message);
                        System.out.println(message);
                        aes = null;

                        aes = new AES();
                        aes.setKey(key);
                        int co = scan.nextInt();
                        message = String.valueOf(co);
                        message = aes.encrypt(message);
                        oos.writeObject(message + "\n");
                        aes = null;

                        aes = new AES();
                        aes.setKey(key);
                        message = (String) ois.readObject();
                        message = aes.decrypt(message);
                        System.out.println("The Balance You asked for is : " + message);
                        aes = null;

                        break;
                    }
                    case 3: {
                        aes = new AES();
                        aes.setKey(key);
                        message = (String) ois.readObject();
                        message = aes.decrypt(message);
                        System.out.println("The Total Balance is : " + message);
                        break;
                    }
                    case 4: {
                        //exchange puplic keys
                        BigInteger clientN = rsa.getN();
                        BigInteger clientE = rsa.getE();
                        BigInteger serverN = (BigInteger) secOis.readObject();
                        BigInteger serverE = (BigInteger) secOis.readObject();
                        secOos.writeObject(clientN);
                        secOos.writeObject(clientE);

                        message = new String(recvRsaMessage(rsa, ois, secOis, serverN, serverE).toByteArray());
                        System.out.println(message);

                        int client = scan.nextInt();
                        senRsaMessage(rsa, new BigInteger(String.valueOf(client).getBytes()), serverN, serverE, secOos, oos);

                        message = new String(recvRsaMessage(rsa, ois, secOis, serverN, serverE).toByteArray());
                        System.out.println(message);

                        float value = scan.nextFloat();
                        senRsaMessage(rsa, new BigInteger(String.valueOf(value).getBytes()), serverN, serverE, secOos, oos);

                        message = new String(recvRsaMessage(rsa, ois, secOis, serverN, serverE).toByteArray());
                        System.out.println(message);

//                        if (message.charAt(0) == 'Y') {
//                            BigInteger rec = recvRsaMessage(rsa, ois, secOis, serverN, serverE);
//                            transactions.addTransaction((Transaction) SerializationTool.deSerialize(rec.toByteArray()));
//                        }
                        break;
                    }
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                oos.close();
                ois.close();
                secOis.close();
                secOos.close();
                socket.close();
            } catch (IOException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private static void senRsaMessage(RSA rsa, BigInteger message, BigInteger serverN, BigInteger serverE, ObjectOutputStream secOos, ObjectOutputStream oos) throws IOException {

        //encrypt with server public key
        RSA tempRsa = new RSA(serverN, serverE);
        BigInteger cypher = tempRsa.encrypt(message);

        //hashing the cypher
        BigInteger hash = SHA512.hash(cypher);

        //digital signature
        BigInteger digitalSignature = rsa.encryptViceVersa(hash);

        //sending
        oos.writeObject(cypher);
        secOos.writeObject(digitalSignature);
    }

    private static BigInteger recvRsaMessage(RSA rsa, ObjectInputStream ois, ObjectInputStream secOis, BigInteger serverN, BigInteger serverE) throws IOException, ClassNotFoundException {
        BigInteger cypher = (BigInteger) ois.readObject();
        BigInteger digitalSignature = (BigInteger) secOis.readObject();

        BigInteger message = rsa.decrypt(cypher);
        BigInteger hash = SHA512.hash(cypher);
        RSA tempRsa = new RSA(serverN, serverE);
        BigInteger hash2 = tempRsa.decryptViceVersa(digitalSignature);
        if (hash.equals(hash2)) {
            return message;
        }
        return null;
    }
}
