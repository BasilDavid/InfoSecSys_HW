/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerClient;

import Cryptography.AES;
import Cryptography.RSA;
import Cryptography.SHA512;
import Cryptography.Transaction;
import Cryptography.Transactions;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import tools.SerializationTool;

/**
 *
 * @author BaSiL DaViD
 */
public class MultiThreadingServer implements Runnable {

    private String key = "iXHD8THFk5rUOGKV8QBp";
    private int users = 5;
    private Thread[] t = new Thread[users];
    private String[] names = new String[users];
    private final int[] ports = new int[users];
    private final int[] secureChannels = new int[users];
    private float[] Balances = new float[users];
    private float sum;
    private RSA rsa;
    private Transactions transactions;

    public MultiThreadingServer() {

        sum = 0;
        for (int i = 0; i < users; i++) {
            ports[i] = i + 3001;
            secureChannels[i] = i + 4001;
            names[i] = String.valueOf(i + 1);
            Balances[i] = (float) Math.random() * 10000;
            sum += Balances[i];
        }
        rsa = new RSA(1024);
        transactions = new Transactions();
    }

    @Override
    public void run() {
        int id = Integer.parseInt(Thread.currentThread().getName());
        ServerSocket myServer = null;
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;

        ServerSocket secMyServer = null;
        ObjectInputStream secOis = null;
        ObjectOutputStream secOos = null;
        try {
            myServer = new ServerSocket(ports[id - 1]);
            Socket clientSocket;
            System.out.println("Listening on port : " + ports[id - 1]);

            secMyServer = new ServerSocket(secureChannels[id - 1]);
            Socket secClientSocket;
            System.out.println("Listening on port : " + secureChannels[id - 1]);

            clientSocket = myServer.accept();
            System.out.println("Client on port : " + ports[id - 1] + " is Activated");
            oos = new ObjectOutputStream(clientSocket.getOutputStream());
            ois = new ObjectInputStream(clientSocket.getInputStream());

            secClientSocket = secMyServer.accept();
            System.out.println("Client on port : " + secureChannels[id - 1] + " is Activated");
            secOos = new ObjectOutputStream(secClientSocket.getOutputStream());
            secOis = new ObjectInputStream(secClientSocket.getInputStream());

            while (true) {
                System.out.println("Client on port : " + ports[id - 1] + " still Connected");

                AES aes = new AES();
                aes.setKey(key);
                String message = "Welcome To Crypto Currency Project\n"
                        + "Press 1: To Check your Balance.\n"
                        + "Press 2: To Check Someones Balance.\n"
                        + "Press 3: To Check The Hole Balances.\n"
                        + "Press 4: To Make a Transaction.";

                message = aes.encrypt(message);
                oos.writeObject(message + "\n");
                aes = null;

                aes = new AES();
                aes.setKey(key);
                message = (String) ois.readObject();
                int state = Integer.parseInt(aes.decrypt(message));
                aes = null;

                switch (state) {
                    case 1: {
                        aes = new AES();
                        aes.setKey(key);
                        message = aes.encrypt(String.valueOf(Balances[id - 1]));
                        oos.writeObject(message + "\n");
                        aes = null;

                        System.out.println("Client on port ( " + ports[id - 1] + " ) Choosed 1 and Served");
                        break;
                    }
                    case 2: {
                        aes = new AES();
                        aes.setKey(key);
                        message = "Please Choose a Client [1.." + String.valueOf(users) + "] ";
                        message = aes.encrypt(message);
                        oos.writeObject(message + "\n");
                        aes = null;

                        aes = new AES();
                        aes.setKey(key);
                        message = (String) ois.readObject();
                        message = aes.decrypt(message);
                        int i = Integer.parseInt(message);
                        aes = null;

                        aes = new AES();
                        aes.setKey(key);
                        message = String.valueOf(Balances[i - 1]);
                        message = aes.encrypt(message);
                        oos.writeObject(message + "\n");
                        aes = null;

                        System.out.println("Client on port ( " + ports[id - 1] + " ) Choosed 2 and Served");
                        break;
                    }
                    case 3: {
                        aes = new AES();
                        aes.setKey(key);
                        message = String.valueOf(sum);
                        message = aes.encrypt(message);
                        oos.writeObject(message + "\n");
                        aes = null;

                        System.out.println("Client on port ( " + ports[id - 1] + " ) Choosed 3 and Served");
                        break;
                    }
                    case 4: {
                        //exchange puplic keys
                        BigInteger serverN = rsa.getN();
                        BigInteger serverE = rsa.getE();
                        secOos.writeObject(serverN);
                        secOos.writeObject(serverE);
                        BigInteger clientN = (BigInteger) secOis.readObject();
                        BigInteger clientE = (BigInteger) secOis.readObject();

                        message = "Choose Client to Make your Transaction. \n";
                        senRsaMessage(new BigInteger(message.getBytes()), clientN, clientE, secOos, oos);

                        message = new String(recvRsaMessage(ois, secOis, clientN, clientE)[0].toByteArray());
                        int client = Integer.parseInt(message);

                        message = "Choose Value to Make your Transaction. \n";
                        senRsaMessage(new BigInteger(message.getBytes()), clientN, clientE, secOos, oos);

                        BigInteger[] messages = recvRsaMessage(ois, secOis, clientN, clientE);
                        float value = Float.parseFloat(new String(messages[0].toByteArray()));

                        if (value <= Balances[id - 1]) {
                            Balances[id - 1] -= value;
                            Balances[client - 1] += value;
                            message = "You Make the Transaction Successfully.\n";
                            senRsaMessage(new BigInteger(message.getBytes()), clientN, clientE, secOos, oos);

                            Transaction t = new Transaction(value, id + "", client + "", new String(messages[1].toByteArray()));
                            transactions.addTransaction(t);

//                            senRsaMessage(new BigInteger(SerializationTool.serialize(t)), clientN, clientE, secOos, oos);

                        } else {
                            message = "Failed to Make the Transaction {You Don't Have Enough Money}.\n";
                            senRsaMessage(new BigInteger(message.getBytes()), clientN, clientE, secOos, oos);
                        }
                        break;
                    }
                }

                oos.flush();
                secOos.flush();

                Thread.sleep(5000);
            }

        } catch (IOException ex) {
            Logger.getLogger(MultiThreadingServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(MultiThreadingServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MultiThreadingServer.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                myServer.close();
                oos.close();
                ois.close();
                secOos.close();
                secOis.close();
            } catch (IOException ex) {
                Logger.getLogger(MultiThreadingServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void senRsaMessage(BigInteger message, BigInteger clientN, BigInteger clientE, ObjectOutputStream secOos, ObjectOutputStream oos) throws IOException {

        //encrypt with client public key
        RSA tempRsa = new RSA(clientN, clientE);
        BigInteger cypher = tempRsa.encrypt(message);

        //hashing the cypher
        BigInteger hash = SHA512.hash(cypher);

        //digital signature
        BigInteger digitalSignature = rsa.encryptViceVersa(hash);

        //sending
        oos.writeObject(cypher);
        secOos.writeObject(digitalSignature);
    }

    private BigInteger[] recvRsaMessage(ObjectInputStream ois, ObjectInputStream secOis, BigInteger clientN, BigInteger clientE) throws IOException, ClassNotFoundException {
        BigInteger cypher = (BigInteger) ois.readObject();
        BigInteger digitalSignature = (BigInteger) secOis.readObject();

        BigInteger message = rsa.decrypt(cypher);
        BigInteger hash = SHA512.hash(cypher);
        RSA tempRsa = new RSA(clientN, clientE);
        BigInteger hash2 = tempRsa.decryptViceVersa(digitalSignature);
        if (hash.equals(hash2)) {
            return new BigInteger[]{message, digitalSignature};
        }
        return null;
    }

    public void start() {
        System.out.println("Starting The MultiThreading Server");
        for (int i = 0; i < t.length; i++) {
            if (t[i] == null) {
                t[i] = new Thread(this, names[i]);
                t[i].start();
            }
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        MultiThreadingServer st = new MultiThreadingServer();
        st.start();

//        BigInteger b = new BigInteger("asdada".getBytes());
//        RSA rsa = new RSA(1024);
//        b = rsa.encrypt(b);
//        b = rsa.decrypt(b);
//        System.out.println(new String(b.toByteArray()));
//        Transaction t = new Transaction(5, "kjk", "hj", "ngk");
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        ObjectOutputStream out = new ObjectOutputStream(bos);
//        out.writeObject(t);
//        byte[] buf = bos.toByteArray();
//        out.close();
//        bos.close();
//        
//        BigInteger bi = new BigInteger(buf);
//        
//        byte[] data = bi.toByteArray();
//        
//        ByteArrayInputStream in = new ByteArrayInputStream(data);
//        ObjectInputStream is = new ObjectInputStream(in);
//        t =  (Transaction) is.readObject();
//        System.out.println(t.getValue());
    }

}
